<?php

Class M_penyakit extends CI_Model {

	public function penyakit_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('penyakit')->result_array();
		}else{
			return $this->db->get_where('penyakit',['kode_penyakit' => $id])->row();
		}
	}

	public function penyakit_post($data)
	{
		$this->db->insert('penyakit',$data);
		return $this->db->affected_rows();
	}

	public function penyakit_put($data,$id)
	{
		$this->db->update('penyakit',$data,['kode_penyakit' => $id]);
		return $this->db->affected_rows();
	}

	public function penyakit_delete($id)
	{
		$this->db->delete('penyakit',['kode_penyakit' => $id]);
		return $this->db->affected_rows();
	}

	public function num_rows_penyakit()
	{
		return $this->db->get('penyakit')->num_rows();
	}
}