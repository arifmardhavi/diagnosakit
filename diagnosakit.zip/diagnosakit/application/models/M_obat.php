<?php

Class M_obat extends CI_Model {

	// harus diperbarui
	public function obat_get($id = null)
	{
		if ($id == null) {
			$query = "select * from obat LEFT JOIN penyakit ON penyakit.kode_penyakit = obat.penyakit ";
			return $this->db->query($query)->result_array();
		}else{
			return $this->db->get_where('obat',['kode_obat' => $id])->result_array();
		}
	}

	// baru
	public function detail_obat_get($id)
	{
			$query = "select * from obat LEFT JOIN penyakit ON penyakit.kode_penyakit = obat.penyakit where kode_obat= '$id' ";
			return $this->db->query($query)->row();
	}

	public function obat_post($data)
	{
		$this->db->insert('obat',$data);
		return $this->db->affected_rows();
	}

	public function obat_put($data,$id)
	{
		$this->db->update('obat',$data,['kode_obat' => $id]);
		return $this->db->affected_rows();
	}

	public function obat_delete($id)
	{
		$this->db->delete('obat',['kode_obat' => $id]);
		return $this->db->affected_rows();
	}

	public function num_rows_obat()
	{
		return $this->db->get('obat')->num_rows();
	}
	public function upload_image($image)
	{
		$config['upload_path']          = './assets/obat/';
	    $config['allowed_types']        = 'gif|jpg|png';
	    $config['file_name']            = $image;
	    $config['overwrite']			= true;
	    $config['max_size']             = 5120; // 1MB
	    // $config['max_width']            = 1024;
	    // $config['max_height']           = 768;

	    $this->load->library('upload', $config);

	    if ($this->upload->do_upload('image')) {
	        return $this->upload->data("file_name");
	    }
	}

	// baru
	public function obat_penyakit_get($kode_penyakit)
	{
		$query ="SELECT * FROM obat LEFT JOIN penyakit ON penyakit.kode_penyakit = obat.penyakit WHERE penyakit.kode_penyakit = '$kode_penyakit'";
		return $this->db->query($query)->result_array();
	}
}