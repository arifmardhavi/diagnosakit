<?php

Class M_data_diagnosa extends CI_Model {

	public function data_diagnosa_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('data_diagnosa')->result_array();
		}else{
			return $this->db->get_where('data_diagnosa',['kode_data_diagnosa' => $id])->row();
		}
	}

	public function data_diagnosa_post($data)
	{
		$this->db->insert('data_diagnosa',$data);
		return $this->db->affected_rows();
	}

	public function data_diagnosa_put($data,$id)
	{
		$this->db->update('data_diagnosa',$data,['kode_data_diagnosa' => $id]);
		return $this->db->affected_rows();
	}

	public function data_diagnosa_delete($id)
	{
		$this->db->delete('data_diagnosa',['kode_data_diagnosa' => $id]);
		return $this->db->affected_rows();
	}

	public function num_rows_diagnosa()
	{
		return $this->db->get('data_diagnosa')->num_rows();
	}

	public function riwayat_diagnosa_user($kode_user)
	{
		$query = "select * from data_diagnosa LEFT JOIN user ON user.kode_user = data_diagnosa.kode_user LEFT JOIN penyakit on data_diagnosa.kode_penyakit = penyakit.kode_penyakit where data_diagnosa.kode_user = '$kode_user' order by data_diagnosa.tanggal desc ";
		return $this->db->query($query)->result_array();
	}

	public function riwayat_diagnosa()
	{
		$query = "select * from data_diagnosa LEFT JOIN user ON user.kode_user = data_diagnosa.kode_user order by data_diagnosa.tanggal desc limit 5 ";
		return $this->db->query($query)->result_array();
	}
}