<?php

Class M_user extends CI_Model {

	public function user_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('user')->result_array();
		}else{
			return $this->db->get_where('user',['kode_user' => $id])->row();
		}
	}

	// baru
	public function login_get($username,$password)
	{
		$query = "SELECT * FROM `user` WHERE username = '$username' && password = '$password' ";
		return $this->db->query($query)->row();
	}

	//baru
	public function usepass_put($kode_user,$username,$password)
	{
		$query = "UPDATE user SET username = '$username',password = '$password' WHERE kode_user = '$kode_user' ";
		$this->db->query($query);
		return $this->db->affected_rows();
	}

	public function user_post($data)
	{
		$this->db->insert('user',$data);
		return $this->db->affected_rows();
	}

	public function user_put($data,$id)
	{
		$this->db->update('user',$data,['kode_user' => $id]);
		return $this->db->affected_rows();
	}

	public function user_delete($id)
	{
		$this->db->delete('user',['kode_user' => $id]);
		return $this->db->affected_rows();
	}

	public function num_rows_user()
	{
		return $this->db->get('user')->num_rows();
	}
}