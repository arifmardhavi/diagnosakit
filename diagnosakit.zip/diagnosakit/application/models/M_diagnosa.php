<?php

Class M_diagnosa extends CI_Model {

	public function diagnosis($data)
	{
		$query = $this->db->query(
			"SELECT 
	nama_penyakit,
    (select count(kode_gejala) from gejala_penyakit where gejala_penyakit.kode_penyakit=penyakit.kode_penyakit) as jumlah_gejala_yang_harus_terpenuhi,
    (select count(kode_gejala) from gejala_penyakit where gejala_penyakit.kode_penyakit=penyakit.kode_penyakit and gejala_penyakit.kode_gejala IN $data) as gejala_terpenuhi,
    (((select count(kode_gejala) from gejala_penyakit where gejala_penyakit.kode_penyakit=penyakit.kode_penyakit and gejala_penyakit.kode_gejala IN $data) / (select count(kode_gejala) from gejala_penyakit where gejala_penyakit.kode_penyakit=penyakit.kode_penyakit)) * 100 ) as persentase
from penyakit where (((select count(kode_gejala) from gejala_penyakit where gejala_penyakit.kode_penyakit=penyakit.kode_penyakit and gejala_penyakit.kode_gejala IN $data) / (select count(kode_gejala) from gejala_penyakit where gejala_penyakit.kode_penyakit=penyakit.kode_penyakit)) * 100 ) > 0  order by persentase desc"
		);
		return $query->result();

	}
}