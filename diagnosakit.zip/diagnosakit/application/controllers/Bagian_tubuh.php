<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Bagian_tubuh extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_bagian_tubuh','bagian_tubuh');
    }

    public function bagian_tubuh_get()
    {
        $id = $this->get('kode_bagian');

        if ($id == null ) {
            $bagian_tubuh = $this->bagian_tubuh->bagian_tubuh_get();
        }else{
            $bagian_tubuh = $this->bagian_tubuh->bagian_tubuh_get($id);
        }

        if ($bagian_tubuh) {
            $this->response([
                'status' => true,
                'data' => $bagian_tubuh
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function bagian_tubuh_post()
    {
        $kode_bagian = $this->lib_code->generate_code('BGN', 'bagian_tubuh', 'kode_bagian', 4);
        $data = [
            'kode_bagian' => $kode_bagian,
            'nama_bagian' => $this->post('nama_bagian'),
        ];

        if ($this->bagian_tubuh->bagian_tubuh_post($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data has been created'
            ], REST_Controller::HTTP_CREATED);
        }else{
            $this->response([
                'status' => FALSE,
                'message' => 'failed to created'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function bagian_tubuh_put()
    {
        $id = $this->put('kode_bagian');
        $kode_bagian = $this->lib_code->generate_code('OBT', 'bagian_tubuh', 'kode_bagian', 4);
        $data = [
            'kode_bagian' => $kode_bagian,
            'nama_bagian' => $this->put('nama_bagian')
        ];  

        if ($this->bagian_tubuh->bagian_tubuh_put($data,$id) > 0 ) {
            $this->response([
                'status' => true,
                'message' => 'data has been updated'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function bagian_tubuh_delete()
    {
        $id = $this->delete('kode_bagian');
        if ($id == null) {
            $this->response([
                    'status' => false,
                    'message' => 'provide an id!',
                    'data' => $id
                ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if ($this->bagian_tubuh->bagian_tubuh_delete($id) > 0 ) {
                // ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted'
                ], REST_Controller::HTTP_OK);
            }else{
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }
}