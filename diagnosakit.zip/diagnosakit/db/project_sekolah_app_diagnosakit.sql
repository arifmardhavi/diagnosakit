-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Agu 2019 pada 13.41
-- Versi server: 10.1.34-MariaDB
-- Versi PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_sekolah_app_diagnosakit`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_diagnosa`
--

CREATE TABLE `data_diagnosa` (
  `kode_data_diagnosa` varchar(25) NOT NULL,
  `kode_user` varchar(25) NOT NULL,
  `kode_penyakit` varchar(25) NOT NULL,
  `tanggal` datetime NOT NULL,
  `lokasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_diagnosa`
--

INSERT INTO `data_diagnosa` (`kode_data_diagnosa`, `kode_user`, `kode_penyakit`, `tanggal`, `lokasi`) VALUES
('DNS-19H07-053434-0001', 'asd', 'asdasd', '2002-11-02 00:00:00', '12312as');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_diagnosa_gejala`
--

CREATE TABLE `data_diagnosa_gejala` (
  `kode_data_diagnosa` varchar(25) NOT NULL,
  `kode_gejala` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_diagnosa_gejala`
--

INSERT INTO `data_diagnosa_gejala` (`kode_data_diagnosa`, `kode_gejala`) VALUES
('DNS-19H07-053434-0001', '1909'),
('DNS-19H07-053434-0001', '1221');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala`
--

CREATE TABLE `gejala` (
  `kode_gejala` varchar(22) NOT NULL,
  `nama_gejala` varchar(30) NOT NULL,
  `jenis_gejala` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gejala`
--

INSERT INTO `gejala` (`kode_gejala`, `nama_gejala`, `jenis_gejala`) VALUES
('GJL-19H07-050101-0001', 'gejala1', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala_penyakit`
--

CREATE TABLE `gejala_penyakit` (
  `kode_penyakit` varchar(22) NOT NULL,
  `kode_gejala` varchar(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gejala_penyakit`
--

INSERT INTO `gejala_penyakit` (`kode_penyakit`, `kode_gejala`) VALUES
('SKT-19H07-050404-0001', '1909'),
('SKT-19H07-050404-0001', '1221'),
('SKT-19H07-050202-0001', '1109'),
('SKT-19H07-050202-0001', '2221');

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE `obat` (
  `kode_obat` varchar(22) NOT NULL,
  `nama_obat` varchar(20) NOT NULL,
  `jenis_obat` varchar(20) NOT NULL,
  `penyakit` varchar(30) NOT NULL,
  `gambar` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`kode_obat`, `nama_obat`, `jenis_obat`, `penyakit`, `gambar`) VALUES
('OBT-19H07-055757-0001', 'obat1', 'asd', 'asdjk', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyakit`
--

CREATE TABLE `penyakit` (
  `kode_penyakit` varchar(22) NOT NULL,
  `nama_penyakit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `penyakit`
--

INSERT INTO `penyakit` (`kode_penyakit`, `nama_penyakit`) VALUES
('SKT-19H07-050404-0001', 'asd'),
('SKT-19H07-050202-0001', 'asaasd');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `kode_user` varchar(22) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`kode_user`, `nama`, `email`, `username`, `password`, `tanggal_lahir`, `gender`) VALUES
('USR-19H07-051010-0001', 'arif mardhavi', 'arifmardhavi@gmail.com', 'arifmardhavi', '11maret2002', '0000-00-00', 'lak'),
('USR-19H07-050505-0001', 'arif mardhavi1', 'arifmardhavi@gmail.com', 'arifmardhavi1', '11maret2002', '2002-03-11', 'laki');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_admin`
--

CREATE TABLE `user_admin` (
  `kode_admin` varchar(22) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_admin`
--

INSERT INTO `user_admin` (`kode_admin`, `username`, `password`) VALUES
('UDM-19H07-054343-0001', 'arifmardhavi', '11maret2002');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
