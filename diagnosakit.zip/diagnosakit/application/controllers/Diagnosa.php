<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Diagnosa extends REST_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_diagnosa','diagnosa');
        $this->load->model('M_temporary_gejala_penyakit_user','temporary_gejala_penyakit_user');
    }

    public function diagnosa_post()
    {
        $kode_user = $this->post('kode_user');

        $data_akhir1 = $this->temporary_gejala_penyakit_user->temporary_gejala_penyakit_user_get($kode_user);
        $array = array();

        // $array = ['1','2','3'];

        foreach ($data_akhir1 as $dt) {
            $kode_gejala_push = $dt['kode_gejala'];
            $as = array_push($array,$kode_gejala_push);
        }

        $data_gejala = json_encode($array);

        $data_sementara1 =  str_replace('[', '(', $data_gejala);

        $data_sementara2 = str_replace(']', ')', $data_sementara1);

        $data_hasil = str_replace('"', "'", $data_sementara2);

        // $data_akhir = json_encode($data_akhir1);
        // $set = $data_akhir

        //$data_hasil = "('1909', '1221', '1109')";



        $data1 = $this->diagnosa->diagnosis($data_hasil);
        $total_persentase = 0;
        $mistery = array();
        $qwe = array();
        foreach ($data1 as $dt) {
            $total_persentase += $dt->persentase;
            $finish_persentese = array_push($mistery,$total_persentase);
            $ert = $dt->persentase;
            $dfg = array_push($qwe,$ert);
        }   
        $persentase_akhir = ($data1[0]->persentase / $total_persentase) * 100;

        $asd = 0;
        $coba = array();
        foreach ($data1 as $count) {
            $asd += $count->persentase;
            $push1 = array_push($coba,$asd);
        }

        $fgh = array();
        foreach ($data1 as $data) {
            $ert = $data->persentase;
            $persentase_akhi = ($data->persentase / $asd) * 100;
            $pra = round($persentase_akhi);
            $data4 = array(
                'nama_penyakit' => $data->nama_penyakit,
                'jumlah_gejala_yang_harus_terpenuhi' => $data->jumlah_gejala_yang_harus_terpenuhi,
                'gejala_terpenuhi' => $data->gejala_terpenuhi,
                'persentase' => $pra
            );
            $dfg = array_push($fgh,$data4);
        }

        $this->response([
                'status' => true,
                'data_penyakit' => $data1[0],
                'data_persentase' => round($persentase_akhir),
                'all_data' => $fgh
            ], REST_Controller::HTTP_OK);

    }
    
}