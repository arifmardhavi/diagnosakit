<?php

Class M_gejala extends CI_Model {

	public function gejala_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('gejala')->result_array();
		}else{
			return $this->db->get_where('gejala',['kode_gejala' => $id])->result_array();
		}
	}

	public function gejala_bagian_get($kode_bagian)
	{
		$query = "select * from gejala where kode_bagian = '$kode_bagian' ";
		return $this->db->query($query)->result_array();
	}

	public function gejala_post($data)
	{
		$this->db->insert('gejala',$data);
		return $this->db->affected_rows();
	}

	public function gejala_put($data,$id)
	{
		$this->db->update('gejala',$data,['kode_gejala' => $id]);
		return $this->db->affected_rows();
	}

	public function gejala_delete($id)
	{
		$this->db->delete('gejala',['kode_gejala' => $id]);
		return $this->db->affected_rows();
	}
}