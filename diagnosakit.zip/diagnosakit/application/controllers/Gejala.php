<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Gejala extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_gejala','gejala');
    }

    public function gejala_get()
    {
        $id = $this->get('kode_gejala');

        if ($id == null ) {
            $gejala = $this->gejala->gejala_get();
        }else{
            $gejala = $this->gejala->gejala_get($id);
        }

        if ($gejala) {
            $this->response([
                'status' => true,
                'data' => $gejala
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function gejala_bagian_get()
    {
        $kode_bagian = $this->get('kode_bagian');
        $gejala = $this->gejala->gejala_bagian_get($kode_bagian);
        if ($gejala > 0) {
            $this->response([
                'status' => true,
                'data' => $gejala
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'gejala tidak ditemukan'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function gejala_post()
    {
        $kode_gejala = $this->lib_code->generate_code('GJL', 'gejala', 'kode_gejala', 4);
        $data = [
            'kode_gejala' => $kode_gejala,
            'nama_gejala' => $this->post('nama_gejala'),
            'kode_bagian' => $this->post('kode_bagian')
        ];

        if ($this->gejala->gejala_post($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data has been created'
            ], REST_Controller::HTTP_CREATED);
        }else{
            $this->response([
                'status' => FALSE,
                'message' => 'failed to created'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function gejala_put()
    {
        $id = $this->put('kode_gejala');
        $kode_gejala = $this->lib_code->generate_code('GJL', 'gejala', 'kode_gejala', 4);
        $data = [
            'kode_gejala' => $kode_gejala,
            'nama_gejala' => $this->put('nama_gejala'),
            'kode_bagian' => $this->put('kode_bagian')
        ];  

        if ($this->gejala->gejala_put($data,$id) > 0 ) {
            $this->response([
                'status' => true,
                'message' => 'data has been updated'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function gejala_delete()
    {
        $id = $this->delete('kode_gejala');
        if ($id == null) {
            $this->response([
                    'status' => false,
                    'message' => 'provide an id!',
                    'data' => $id
                ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if ($this->gejala->gejala_delete($id) > 0 ) {
                // ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted'
                ], REST_Controller::HTTP_OK);
            }else{
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }
}