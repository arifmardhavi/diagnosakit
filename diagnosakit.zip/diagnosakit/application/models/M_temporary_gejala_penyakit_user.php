<?php

Class M_temporary_gejala_penyakit_user extends CI_Model {

	public function temporary_gejala_penyakit_user_get($kode_user)
	{
		$query = "select * from temporary_gejala_penyakit_user left join gejala on gejala.kode_gejala = temporary_gejala_penyakit_user.kode_gejala where temporary_gejala_penyakit_user.kode_user = '$kode_user' ";
			return $this->db->query($query)->result_array();
	}

	public function temporary_gejala_penyakit_user_post($data)
	{
		$this->db->insert('temporary_gejala_penyakit_user',$data);
		return $this->db->affected_rows();
	}

	public function temporary_gejala_penyakit_user_delete($kode_gejala,$kode_user)
	{
		$query = "delete from temporary_gejala_penyakit_user where kode_gejala = '$kode_gejala' && kode_user = '$kode_user' ";
		$this->db->query($query);
		return $this->db->affected_rows();
	}
	public function temporary_gejala_penyakit_user_hapus($kode_user)
	{
		return $this->db->query("delete from temporary_gejala_penyakit_user where kode_user = '$kode_user' ")->affected_rows();
	}
}