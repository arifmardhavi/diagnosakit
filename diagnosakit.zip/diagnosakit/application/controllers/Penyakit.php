<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Penyakit extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_penyakit','penyakit');
        $this->load->model('M_gejala_penyakit','gejala_penyakit');
        $this->load->model('M_temporary_gejala_penyakit','temporary_gejala_penyakit');
    }

    public function penyakit_get()
    {
        $id = $this->get('kode_penyakit');

        if ($id == null ) {
            $penyakit = $this->penyakit->penyakit_get();
        }else{
            $penyakit = $this->penyakit->penyakit_get($id);
        }

        if ($penyakit) {
            $this->response([
                'status' => true,
                'data' => $penyakit
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
    public function penyakit_get_join_get()
    {
        $id = $this->get('kode_penyakit');

        if ($id == null ) {
            $penyakit = $this->penyakit->penyakit_get();
        }else{
            $penyakit = $this->penyakit->penyakit_get($id);
        }

        if ($penyakit) {
            $this->response([
                'status' => true,
                'data' => $penyakit
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function penyakit_post()
    {
        $kode_penyakit = $this->lib_code->generate_code('SKT', 'penyakit', 'kode_penyakit', 4);

        $data_penyakit = [
            'kode_penyakit' => $kode_penyakit,
            'nama_penyakit' => $this->post('nama_penyakit')
        ];

        if ($this->penyakit->penyakit_post($data_penyakit) > 0) {
            $data_gejala_penyakit = $this->temporary_gejala_penyakit->temporary_gejala_penyakit_get();
            foreach ($data_gejala_penyakit as $dt) {
                $item_gejala_penyakit = [
                    'kode_penyakit' => $kode_penyakit,
                    'kode_gejala' => str_replace('"','',json_encode($dt['kode_gejala']))
                ];
                $this->gejala_penyakit->gejala_penyakit_post($item_gejala_penyakit);
            }
            $this->temporary_gejala_penyakit->temporary_gejala_penyakit_hapus();
            $this->response([
                'status' => true,
                'message' => 'data berhasil'
            ], REST_Controller::HTTP_CREATED);
        }else{
            $this->response([
                'status' => FALSE,
                'message' => 'failed to created'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function penyakit_put()
    {
        $id = $this->put('kode_penyakit');
        $data = [
            'kode_penyakit' => $id,
            'nama_penyakit' => $this->put('nama_penyakit')
        ];  

        if ($this->penyakit->penyakit_put($data,$id) > 0 ) {
            $this->gejala_penyakit->gejala_penyakit_delete($id);
            $data_gejala_penyakit = $this->temporary_gejala_penyakit->temporary_gejala_penyakit_get();
            foreach ($data_gejala_penyakit as $dt) {
                $item_gejala_penyakit = [
                    'kode_penyakit' => $id,
                    'kode_gejala' => str_replace('"','',json_encode($dt['kode_gejala']))
                ];
                $this->gejala_penyakit->gejala_penyakit_post($item_gejala_penyakit);
            }
            $this->temporary_gejala_penyakit->temporary_gejala_penyakit_hapus();


            $this->response([
                'status' => true,
                'message' => 'data has been updated'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function penyakit_delete()
    {
        $id = $this->delete('kode_penyakit');
        if ($id == null) {
            $this->response([
                    'status' => false,
                    'message' => 'provide an id!',
                    'data' => $id
                ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if ($this->penyakit->penyakit_delete($id) > 0 ) {
                // ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted'
                ], REST_Controller::HTTP_OK);
            }else{
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function num_rows_penyakit_get()
    {
        $data = $this->penyakit->num_rows_penyakit();
        $this->response([
            'status' => true,
            'data' => $data,
            'message' => 'jumlah penyakit ada '.$data
        ], REST_Controller::HTTP_OK);        
    }
}