<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Temporary_gejala_penyakit extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_temporary_gejala_penyakit','temporary_gejala_penyakit');
    }

    public function temporary_gejala_penyakit_get()
    {
        $id = $this->get('kode_gejala');

        if ($id == null ) {
            $temporary_gejala_penyakit = $this->temporary_gejala_penyakit->temporary_gejala_penyakit_get();
        }else{
            $temporary_gejala_penyakit = $this->temporary_gejala_penyakit->temporary_gejala_penyakit_get($id);
        }

        if ($temporary_gejala_penyakit) {
            $this->response([
                'status' => true,
                'data' => $temporary_gejala_penyakit
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function temporary_gejala_penyakit_post()
    {
        $data = [
            'kode_gejala' => $this->post('kode_gejala')
        ];

        if ($this->temporary_gejala_penyakit->temporary_gejala_penyakit_post($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data has been created'
            ], REST_Controller::HTTP_CREATED);
        }else{
            $this->response([
                'status' => FALSE,
                'message' => 'failed to created'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function temporary_gejala_penyakit_delete()
    {
        $id = $this->delete('kode_gejala');
        if ($id == null) {
            $this->response([
                    'status' => false,
                    'message' => 'provide an id!',
                    'data' => $id
                ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if ($this->temporary_gejala_penyakit->temporary_gejala_penyakit_delete($id) > 0 ) {
                // ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted'
                ], REST_Controller::HTTP_OK);
            }else{
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function temporary_gejala_penyakit_hapus()
    {
        $this->temporary_gejala_penyakit->temporary_gejala_penyakit_hapus(); 
        $this->response([
            'status' => true,
            'message' => 'Berhasil dihapus'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}