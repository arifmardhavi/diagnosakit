<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Data_diagnosa extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_data_diagnosa','data_diagnosa');
        $this->load->model('M_data_diagnosa_gejala','data_diagnosa_gejala');
    }

    public function data_diagnosa_get()
    {
        $id = $this->get('kode_data_diagnosa');

        if ($id == null ) {
            $data_diagnosa = $this->data_diagnosa->data_diagnosa_get();
        }else{
            $data_diagnosa = $this->data_diagnosa->data_diagnosa_get($id);
        }

        if ($data_diagnosa) {
            $this->response([
                'status' => true,
                'data' => $data_diagnosa
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function data_diagnosa_post()
    {
        $kode_data_diagnosa = $this->lib_code->generate_code('DNS', 'data_diagnosa', 'kode_data_diagnosa', 4);
        $data_diagnosa = [
            'kode_data_diagnosa' => $kode_data_diagnosa,
            'kode_user' => $this->post('kode_user'),
            'kode_penyakit' => $this->post('kode_penyakit'),
            'tanggal' => $this->post('tanggal'),
            'lokasi' => $this->post('lokasi')
        ];

        if ($this->data_diagnosa->data_diagnosa_post($data_diagnosa) > 0) {
            $data_diagnosa_gejala = $this->post('data_diagnosa_gejala');
            foreach ($data_diagnosa_gejala as $dt) {
                $item_data_diagnosa_gejala = [
                'kode_data_diagnosa' => $kode_data_diagnosa,
                'kode_gejala' => $dt['kode_gejala']
                ];
                $this->data_diagnosa_gejala->data_diagnosa_gejala_post($item_data_diagnosa_gejala);
            }
            $this->response([
                'status' => true,
                'message' => 'data has been created'
            ], REST_Controller::HTTP_CREATED);
        }else{
            $this->response([
                'status' => FALSE,
                'message' => 'failed to created'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function data_diagnosa_put()
    {
        $id = $this->put('kode_data_diagnosa');
        $kode_data_diagnosa = $this->lib_code->generate_code('DNS', 'data_diagnosa', 'kode_data_diagnosa', 4);
        $data = [
            'kode_data_diagnosa' => $kode_data_diagnosa,
            'kode_user' => $this->put('kode_user'),
            'kode_penyakit' => $this->put('kode_penyakit'),
            'tanggal' => $this->put('tanggal'),
            'lokasi' => $this->put('lokasi')
        ];  

        if ($this->data_diagnosa->data_diagnosa_put($data,$id) > 0 ) {
            $this->response([
                'status' => true,
                'message' => 'data has been updated'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function data_diagnosa_delete()
    {
        $id = $this->delete('kode_data_diagnosa');
        if ($id == null) {
            $this->response([
                    'status' => false,
                    'message' => 'provide an id!',
                    'data' => $id
                ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if ($this->data_diagnosa->data_diagnosa_delete($id) > 0 ) {
                // ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted'
                ], REST_Controller::HTTP_OK);
            }else{
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function num_rows_diagnosa_get()
    {
        $data = $this->data_diagnosa->num_rows_diagnosa();
        $this->response([
            'status' => true,
            'data' => $data,
            'message' => 'jumlah diagnosa ada '.$data
        ], REST_Controller::HTTP_OK);        
    }
    // baru
    public function riwayat_diagnosa_user_get()
    {
        $id = $this->get('kode_user');
        $data = $this->data_diagnosa->riwayat_diagnosa_user($id);
        $this->response([
            'status' => true,
            'data' => $data,
            'message' => 'berhasil',
            'asd' => $id
        ], REST_Controller::HTTP_OK);
    }

    public function riwayat_diagnosa_get()
    {
        $data = $this->data_diagnosa->riwayat_diagnosa();
        $this->response([
            'status' => true,
            'data' => $data,
            'message' => 'berhasil '
        ], REST_Controller::HTTP_OK);
    }
}