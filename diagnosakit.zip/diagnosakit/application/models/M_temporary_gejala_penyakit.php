<?php

Class M_temporary_gejala_penyakit extends CI_Model {

	public function temporary_gejala_penyakit_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('temporary_gejala_penyakit')->result_array();
		}else{
			return $this->db->get_where('temporary_gejala_penyakit',['kode_gejala' => $id])->result_array();
		}
	}

	public function temporary_gejala_penyakit_post($data)
	{
		$this->db->insert('temporary_gejala_penyakit',$data);
		return $this->db->affected_rows();
	}

	public function temporary_gejala_penyakit_delete($id)
	{
		$this->db->delete('temporary_gejala_penyakit',['kode_gejala' => $id]);
		return $this->db->affected_rows();
	}
	public function temporary_gejala_penyakit_hapus()
	{
		return $this->db->query("delete from temporary_gejala_penyakit");
	}
}