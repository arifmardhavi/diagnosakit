<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class User extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_user','user');
    }

    public function user_get()
    {
        $id = $this->get('kode_user');

        if ($id == null ) {
            $user = $this->user->user_get();
        }else{
            $user = $this->user->user_get($id);
        }

        if ($user) {
            $this->response([
                'status' => true,
                'data' => $user
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    // baru
    public function login_get()
    {
        $username = $this->get('username');
        $password = $this->get('password');
        $user = $this->user->login_get($username,$password);

        if ($user) {
            $cookies = array(
                'name' => 'kode_user',
                'value' => $user->kode_user,
                'expire' => '2592000' // 1 bulan
            );
            $cookies1 = array(
                'name' => 'nama',
                'value' => $user->nama,
                'expire' => '2592000' // 1 bulan
            );
            $cookies2 = array(
                'name' => 'email',
                'value' => $user->email,
                'expire' => '2592000' // 1 bulan
            );
            $cookies3 = array(
                'name' => 'username',
                'value' => $user->username,
                'expire' => '2592000' // 1 bulan
            );
            $cookies4 = array(
                'name' => 'password',
                'value' => $user->password,
                'expire' => '2592000' // 1 bulan
            );
            $cookies5 = array(
                'name' => 'tanggal_lahir',
                'value' => $user->tanggal_lahir,
                'expire' => '2592000' // 1 bulan
            );
            $cookies6 = array(
                'name' => 'gender',
                'value' => $user->gender,
                'expire' => '2592000' // 1 bulan
            );
            set_cookie($cookies);
            set_cookie($cookies1);
            set_cookie($cookies2);
            set_cookie($cookies3);
            set_cookie($cookies4);
            set_cookie($cookies5);
            set_cookie($cookies6);
            $this->session->set_userdata('kode_user',$user->kode_user);
            $this->session->set_userdata('nama',$user->nama);
            $this->session->set_userdata('username',$user->username);
            $this->session->set_userdata('password',$user->password);
            $this->session->set_userdata('kode_user',$user->tanggal_lahir);
            $this->session->set_userdata('kode_user',$user->gender);
            $_SESSION['kode_user'] = $user->kode_user;
            $this->response([
                'status' => true,
                'data' => $user,
                'session' => $this->session->userdata('kode_user')
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'maaf akun anda tidak ditemukan'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function user_post()
    {
        $kode_user = $this->lib_code->generate_code('USR', 'user', 'kode_user', 4);
        $data = [
            'kode_user' => $kode_user,
            'nama' => $this->post('nama'),
            'email' => $this->post('email'),
            'username' => $this->post('username'),
            'password' => $this->post('password'),
            'tanggal_lahir' => $this->post('tanggal_lahir'),
            'gender' => $this->post('gender'),
            'status' => $this->post('status')
        ];
        if ($this->user->user_post($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data has been created'
            ], REST_Controller::HTTP_CREATED);
        }else{
            $this->response([
                'status' => FALSE,
                'message' => 'failed to created'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
    // baru
    public function user_put()
    {
        // $id = $this->put('kode_user');
        $id = $this->put('kode_user');
        $data = [
            'kode_user' => $id,
            'nama' => $this->put('nama'),
            'email' => $this->put('email'),
            'tanggal_lahir' => $this->put('tanggal_lahir'),
            'gender' => $this->put('gender')
        ];  

        if ($this->user->user_put($data,$id) > 0 ) {
            $user = $this->user->user_get($id);
            $cookies = array(
                'name' => 'kode_user',
                'value' => $user->kode_user,
                'expire' => '2592000' // 1 bulan
            );
            $cookies1 = array(
                'name' => 'nama',
                'value' => $user->nama,
                'expire' => '2592000' // 1 bulan
            );
            $cookies2 = array(
                'name' => 'email',
                'value' => $user->email,
                'expire' => '2592000' // 1 bulan
            );
            $cookies3 = array(
                'name' => 'username',
                'value' => $user->username,
                'expire' => '2592000' // 1 bulan
            );
            $cookies4 = array(
                'name' => 'password',
                'value' => $user->password,
                'expire' => '2592000' // 1 bulan
            );
            $cookies5 = array(
                'name' => 'tanggal_lahir',
                'value' => $user->tanggal_lahir,
                'expire' => '2592000' // 1 bulan
            );
            $cookies6 = array(
                'name' => 'gender',
                'value' => $user->gender,
                'expire' => '2592000' // 1 bulan
            );
            set_cookie($cookies);
            set_cookie($cookies1);
            set_cookie($cookies2);
            set_cookie($cookies3);
            set_cookie($cookies4);
            set_cookie($cookies5);
            set_cookie($cookies6);
            $this->response([
                'status' => true,
                'message' => 'data has been updated'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    // baru
    public function usepass_put()
    {
        $kode_user = $this->put('kode_user');
        $username = $this->put('username');
        $password = $this->put('password');
        $data = [
            'kode_user' => $kode_user,
            'username' => $username,
            'password' => $password
        ];

        if ($this->user->usepass_put($kode_user,$username,$password)) {
            $user = $this->user->user_get($kode_user);
            $cookies = array(
                'name' => 'kode_user',
                'value' => $user->kode_user,
                'expire' => '2592000' // 1 bulan
            );
            $cookies1 = array(
                'name' => 'nama',
                'value' => $user->nama,
                'expire' => '2592000' // 1 bulan
            );
            $cookies2 = array(
                'name' => 'email',
                'value' => $user->email,
                'expire' => '2592000' // 1 bulan
            );
            $cookies3 = array(
                'name' => 'username',
                'value' => $user->username,
                'expire' => '2592000' // 1 bulan
            );
            $cookies4 = array(
                'name' => 'password',
                'value' => $user->password,
                'expire' => '2592000' // 1 bulan
            );
            $cookies5 = array(
                'name' => 'tanggal_lahir',
                'value' => $user->tanggal_lahir,
                'expire' => '2592000' // 1 bulan
            );
            $cookies6 = array(
                'name' => 'gender',
                'value' => $user->gender,
                'expire' => '2592000' // 1 bulan
            );
            set_cookie($cookies);
            set_cookie($cookies1);
            set_cookie($cookies2);
            set_cookie($cookies3);
            set_cookie($cookies4);
            set_cookie($cookies5);
            set_cookie($cookies6);

            $this->response([
                'status' => true,
                'message' => 'data has been updated',
                'data' => $data
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function user_delete()
    {
        $id = $this->session->userdata('kode_user');
        if ($id == null) {
            $this->response([
                    'status' => false,
                    'message' => 'provide an id!',
                    'data' => $id
                ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if ($this->user->user_delete($id) > 0 ) {
                // ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted'
                ], REST_Controller::HTTP_OK);
            }else{
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function blokir_put()
    {
        $id = $this->put('kode_user');
        $data = [
            'status' => $this->put('status')
        ];
        $save = $this->user->user_put($data,$id);

        if ($save > 0 ) {
            if ($id > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'data has been updated'
                ],REST_Controller::HTTP_OK);
            }elseif($id == null){
                $this->response([
                    'status' => false,
                    'message' => 'id kosong'
                ],REST_Controller::HTTP_OK);
            }else{
                $this->response([
                    'status' => false,
                    'message' => 'id tidak ditemukan'.$id
                ],REST_Controller::HTTP_OK);
            }
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'.$id
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function num_rows_user_get()
    {
        $data = $this->user->num_rows_user();
        $this->response([
            'status' => true,
            'data' => $data,
            'message' => 'jumlah user ada '.$data
        ], REST_Controller::HTTP_OK);        
    }
}