<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Obat extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_obat','obat');
    }

    public function obat_get()
    {
        $id = $this->get('kode_obat');

        if ($id == null ) {
            $obat = $this->obat->obat_get();
        }else{
            $obat = $this->obat->obat_get($id);
        }

        if ($obat) {
            $this->response([
                'status' => true,
                'data' => $obat
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }
    // baru
    public function detail_obat_get()
    {
        $id = $this->get('kode_obat');
        $obat = $this->obat->detail_obat_get($id);

        if ($obat) {
            $this->response([
                'status' => true,
                'data' => $obat
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function obat_post()
    {
        $image = '';
        $config['upload_path']          = './assets/obat/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 10240;

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('upload')){
            echo $this->upload->display_errors();
        }else{
            $resize['image_library'] = 'gd2';
            $resize['source_image']  = $this->upload->data('full_path');
            $resize['maintain_ratio']= FALSE;
            $resize['width']         = 400;
            $resize['height']        = 430;             

            $this->load->library('image_lib', $resize);         
            $this->image_lib->resize();
            $image = $this->upload->data('file_name');
            $data = array('upload_data' => $this->upload->data());
        }
        $kode_obat = $this->lib_code->generate_code('OBT', 'obat', 'kode_obat', 4);
        $dari_harga = $this->post('dari_harga');
        $sampai_harga = $this->post('sampai_harga');
        $kisaran_harga = "$dari_harga - $sampai_harga";
        $gambar = $this->obat->upload_image($image);
        $data = [
            'kode_obat' => $kode_obat,
            'nama_obat' => $this->post('nama_obat'),
            'satuan' => $this->post('satuan'),
            'kisaran_harga' => $kisaran_harga,
            'isi' => $this->post('isi'),
            'penyakit' => $this->post('penyakit'),
            'gambar' => $image // name nya upload
        ];

        if ($this->obat->obat_post($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data has been created'.$gambar
            ], REST_Controller::HTTP_CREATED);
        }else{
            $this->response([
                'status' => FALSE,
                'message' => 'failed to created'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function obat_put()
    {
        $id = $this->put('kode_obat');
        $image = '';
        $config['upload_path']          = './assets/obat/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 10240;

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('upload')){
            echo $this->upload->display_errors();
        }else{
            $resize['image_library'] = 'gd2';
            $resize['source_image']  = $this->upload->data('full_path');
            $resize['maintain_ratio']= FALSE;
            $resize['width']         = 400;
            $resize['height']        = 430;             

            $this->load->library('image_lib', $resize);         
            $this->image_lib->resize();
            $image = $this->upload->data('file_name');
            $data = array('upload_data' => $this->upload->data());
        }
        $data = [
            'kode_obat' => $id,
            'nama_obat' => $this->put('nama_obat'),
            'satuan' => $this->put('satuan'),
            'kisaran_harga' => $this->put('kisaran_harga'),
            'isi' => $this->put('isi'),
            'penyakit' => $this->put('penyakit'),
            'gambar' => $image
        ];  

        if ($this->obat->obat_put($data,$id) > 0 ) {
            $this->response([
                'status' => true,
                'message' => 'data has been updated'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function obat_delete()
    {
        $id = $this->delete('kode_obat');
        if ($id == null) {
            $this->response([
                    'status' => false,
                    'message' => 'provide an id!',
                    'data' => $id
                ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if ($this->obat->obat_delete($id) > 0 ) {
                // ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted'
                ], REST_Controller::HTTP_OK);
            }else{
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function num_rows_obat_get()
    {
        $data = $this->obat->num_rows_obat();
        $this->response([
            'status' => true,
            'data' => $data,
            'message' => 'jumlah obat ada '.$data
        ], REST_Controller::HTTP_OK);        
    }

    // baru
    public function obat_penyakit_get()
    {
        $kode_penyakit = $this->get('kode_penyakit');
        $obat = $this->obat->obat_penyakit_get($kode_penyakit);
        if ($obat) {
            $this->response([
                'status' => true,
                'data' => $obat,
                'message' => 'berhasil '
            ], REST_Controller::HTTP_OK);     
        }else{
            $this->response([
                'status' => false,
                'message' => 'gagal'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}