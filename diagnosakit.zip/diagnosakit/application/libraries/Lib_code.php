<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lib_code {
  function __construct() {
       $this->CI =& get_instance();
       $this->CI->load->database();
   }

   function auto_code_w_front_code($front_code, $table, $field, $interval, $jumlah){
      error_reporting(0);
      $query = $this->CI->db->query("select SUBSTRING($field,$interval,$jumlah) as kode from $table where SUBSTRING($field,1,$interval-1)='$front_code' order by $field desc");
      $data = $query->row();
      $kd = $data->kode;
      $code = $kd+1;
      $new_code = sprintf("%0".$jumlah."s", $code);
      return $new_code;
    }

   function generate_code($front_key,$table,$field,$jumlah_kode){
        // Generate Year Code
    $year_code = date("y");

        // Generate Month Code
    $month = date("m");

    if(substr($month,0,1)==0){
      $to_month = substr($month,1,1);
    }else{
      $to_month = $month;
    }

    $array_month = array('','A','B','C','D','E','F','G','H','I','J','K','L');
    $month_code = $array_month[$to_month];

        // Generate Day Code
    $day_code = date("d");

        // Generate Hour Code
    $hour_code = date("H");

        // Generate Minute Code
    $minute_code = date("i");

        // Generate Seconds Code
    $minute_code = date("s");


    $front_code = $front_key.'-'.$year_code.$month_code.$day_code.'-'.$hour_code.$minute_code.$minute_code.'-';

    $interval = strlen($front_code) + 1;
    $back_code = $this->auto_code_w_front_code($front_code,$table,$field,$interval,$jumlah_kode);

    $code = $front_code.$back_code;
    return $code;
  } 

}
