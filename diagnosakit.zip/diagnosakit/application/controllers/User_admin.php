<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class User_admin extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_user_admin','user_admin');
    }

    public function user_admin_get()
    {
        $id = $this->get('kode_admin');

        if ($id == null ) {
            $user_admin = $this->user_admin->user_admin_get();
        }else{
            $user_admin = $this->user_admin->user_admin_get($id);
        }

        if ($user_admin) {
            $this->response([
                'status' => true,
                'data' => $user_admin
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function user_admin_post()
    {
        $kode_admin = $this->lib_code->generate_code('UDM', 'user_admin', 'kode_admin', 4);
        $username = $this->post('username');
        $password = $this->post('password');
        $data = [
            'kode_admin' => $kode_admin,
            'username' => $username,
            'password' => $password
        ];
        if (!empty($username) && !empty($password)) {
            if ($this->user_admin->user_admin_post($data) > 0) {
                $this->response([
                    'status' => true,
                    'message' => 'data has been created'
                ], REST_Controller::HTTP_CREATED);
            }else{
                $this->response([
                    'status' => FALSE,
                    'message' => 'failed to created'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }else{
            $this->response([
                    'status' => FALSE,
                    'message' => 'isi semua form'
                ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function user_admin_put()
    {
        $id = $this->put('kode_admin');
        $kode_admin = $this->lib_code->generate_code('UDM', 'user_admin', 'kode_admin', 4);
        $data = [
            'kode_admin' => $kode_admin,
            'username' => $this->put('username'),
            'password' => $this->put('password')
        ];  

        if ($this->user_admin->user_admin_put($data,$id) > 0 ) {
            $this->response([
                'status' => true,
                'message' => 'data has been updated'
            ],REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'failed to update data'
            ],REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function user_admin_delete()
    {
        $id = $this->delete('kode_admin');
        if ($id == null) {
            $this->response([
                    'status' => false,
                    'message' => 'provide an id!',
                    'data' => $id
                ], REST_Controller::HTTP_BAD_REQUEST);
        }else{
            if ($this->user_admin->user_admin_delete($id) > 0 ) {
                // ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted'
                ], REST_Controller::HTTP_OK);
            }else{
                // id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }
}