1. crud penyakit -> gejala_penyakit v
2. crud gejala v
3. crud obat v
4. crud user v
5. crud user_admin v
6. crud data_diagnosa -> data_diagnosa_gejala v

