<?php

Class M_data_diagnosa_gejala extends CI_Model {

	public function data_diagnosa_gejala_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('data_diagnosa_gejala')->result_array();
		}else{
			return $this->db->get_where('data_diagnosa_gejala',['kode_data_diagnosa_gejala' => $id])->result_array();
		}
	}

	public function data_diagnosa_gejala_post($data)
	{
		$this->db->insert('data_diagnosa_gejala',$data);
		return $this->db->affected_rows();
	}

	public function data_diagnosa_gejala_put($data,$id)
	{
		$this->db->update('data_diagnosa_gejala',$data,['kode_data_diagnosa_gejala' => $id]);
		return $this->db->affected_rows();
	}

	public function data_diagnosa_gejala_delete($id)
	{
		$this->db->delete('data_diagnosa_gejala',['kode_data_diagnosa_gejala' => $id]);
		return $this->db->affected_rows();
	}
}