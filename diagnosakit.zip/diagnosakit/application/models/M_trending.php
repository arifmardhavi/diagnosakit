<?php

Class M_trending extends CI_Model {

	public function trending_get()
	{
		$query = "SELECT data_diagnosa.kode_penyakit,penyakit.nama_penyakit,COUNT(data_diagnosa.kode_penyakit) AS jumlah FROM data_diagnosa LEFT JOIN penyakit ON penyakit.kode_penyakit=data_diagnosa.kode_penyakit GROUP BY data_diagnosa.kode_penyakit ORDER BY jumlah DESC LIMIT 10";
		return $this->db->query($query)->result_array();
	}
	public function num_row_trending()
	{
		return $this->db->query('select * from data_diagnosa')->num_rows();
	}
}