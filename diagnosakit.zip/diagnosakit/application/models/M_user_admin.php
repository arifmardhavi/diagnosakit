<?php

Class M_user_admin extends CI_Model {

	public function user_admin_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('user_admin')->result_array();
		}else{
			return $this->db->get_where('user_admin',['kode_user_admin' => $id])->result_array();
		}
	}

	public function user_admin_post($data)
	{
		$this->db->insert('user_admin',$data);
		return $this->db->affected_rows();
	}

	public function user_admin_put($data,$id)
	{
		$this->db->update('user_admin',$data,['kode_user_admin' => $id]);
		return $this->db->affected_rows();
	}

	public function user_admin_delete($id)
	{
		$this->db->delete('user_admin',['kode_user_admin' => $id]);
		return $this->db->affected_rows();
	}
}