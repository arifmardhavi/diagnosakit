<?php

Class M_bagian_tubuh extends CI_Model {

	public function bagian_tubuh_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('bagian_tubuh')->result_array();
		}else{
			return $this->db->get_where('bagian_tubuh',['kode_bagian' => $id])->result_array();
		}
	}

	public function bagian_tubuh_post($data)
	{
		$this->db->insert('bagian_tubuh',$data);
		return $this->db->affected_rows();
	}

	public function bagian_tubuh_put($data,$id)
	{
		$this->db->update('bagian_tubuh',$data,['kode_bagian' => $id]);
		return $this->db->affected_rows();
	}

	public function bagian_tubuh_delete($id)
	{
		$this->db->delete('bagian_tubuh',['kode_bagian' => $id]);
		return $this->db->affected_rows();
	}
}