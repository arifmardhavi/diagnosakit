<?php

Class M_gejala_penyakit extends CI_Model {

	public function gejala_penyakit_get($id = null)
	{
		if ($id == null) {
			return $this->db->get('gejala_penyakit')->result_array();
		}else{
			return $this->db->get_where('gejala_penyakit',['kode_penyakit' => $id])->result_array();
		}
	}

	public function gejala_penyakit_post($data)
	{
		$this->db->insert('gejala_penyakit',$data);
		return $this->db->affected_rows();
	}

	public function gejala_penyakit_put($data,$id)
	{
		$this->db->update('gejala_penyakit',$data,['kode_penyakit' => $id]);
		return $this->db->affected_rows();
	}

	public function gejala_penyakit_delete($id)
	{
		$this->db->delete('gejala_penyakit',['kode_penyakit' => $id]);
		return $this->db->affected_rows();
	}
	// public function gejala_penyakit_update($kode_penyakit,$kode_gejala)
	// {
	// 	$query = "update gejala_penyakit set kode_penyakit = '$kode_penyakit',kode_gejala = '$kode_gejala' where kode_penyakit ='$kode_penyakit' ";
	// 	$this->db query($query);
	// 	return $this->db->affected_rows();
	// }
}