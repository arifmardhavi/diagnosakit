<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Temporary_gejala_penyakit_user extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_temporary_gejala_penyakit_user','temporary_gejala_penyakit_user');
    }

    public function temporary_gejala_penyakit_user_get()
    {
        $kode_user = $this->get('kode_user');
        $temporary_gejala_penyakit_user = $this->temporary_gejala_penyakit_user->temporary_gejala_penyakit_user_get($kode_user);

        if ($temporary_gejala_penyakit_user) {
            $this->response([
                'status' => true,
                'data' => $temporary_gejala_penyakit_user
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function temporary_gejala_penyakit_user_post()
    {
        $data = [
            'kode_gejala' => $this->post('kode_gejala'),
            'kode_user' => $this->post('kode_user')
        ];

        if ($this->temporary_gejala_penyakit_user->temporary_gejala_penyakit_user_post($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data has been created'
            ], REST_Controller::HTTP_CREATED);
        }else{
            $this->response([
                'status' => FALSE,
                'message' => 'failed to created'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function temporary_gejala_penyakit_user_delete()
    {
        $kode_gejala = $this->delete('kode_gejala');
        $kode_user = $this->delete('kode_user');
        if ($this->temporary_gejala_penyakit_user->temporary_gejala_penyakit_user_delete($kode_gejala,$kode_user) > 0 ) {
            // ok
            $this->response([
                'status' => true,
                'kode_user' => $kode_user,
                'kode_gejala' => $kode_gejala,
                'message' => 'deleted'
            ], REST_Controller::HTTP_OK);
        }else{
            // id not found
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function temporary_gejala_penyakit_user_hapus_delete()
    {
        $kode_user = $this->delete('kode_user');
        $this->temporary_gejala_penyakit_user->temporary_gejala_penyakit_user_hapus($kode_user); 
        $this->response([
            'status' => true,
            'message' => 'Berhasil dihapus'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}