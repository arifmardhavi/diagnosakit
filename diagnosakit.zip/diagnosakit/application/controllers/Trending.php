<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


Class Trending extends REST_Controller {

    public function __construct()
    {
        
        parent::__construct();
        $this->load->model('M_trending','trending');
    }

    public function trending_get()
    {
        $trending = $this->trending->trending_get();

        if ($trending) {
            $this->response([
                'status' => true,
                'data' => $trending
            ], REST_Controller::HTTP_OK);
        }else{
            $this->response([
                'status' => false,
                'message' => 'Maaf gagal karena kesalahan teknis'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function num_rows_trending_get()
    {
        $data = $this->trending->num_row_trending();
        $this->response([
            'status' => true,
            'data' => $data,
            'message' => 'jumlah trending ada '.$data
        ], REST_Controller::HTTP_OK);
    }
}